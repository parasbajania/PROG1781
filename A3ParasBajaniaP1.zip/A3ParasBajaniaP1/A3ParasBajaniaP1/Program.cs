﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3ParasBajaniaP1
{
   
    class Program
    {
        
        static void Main(string[] args)
        {
            repeat:
            Console.WriteLine("MENU:");
            Console.WriteLine("1. Even numbers beginning at 0");
            Console.WriteLine("2.A sequence of perfect squares");
            Console.WriteLine("3.exit");
            try
            {
                string choose = Console.ReadLine();
                switch (choose)
                {
                    case "1":
                        Console.WriteLine("Even numbers to be displayed?");
                        string n = Console.ReadLine();
                        int num = int.Parse(n);
                        for (int l = 0; l < num * 2; l++)
                        {
                            if (l % 2 == 0)
                            {
                                Console.WriteLine(l);
                            }
                        }
                        break;
                    case "2":
                        int v = 1;
                        while (v >= 0)
                        {
                            int a = v * v;
                            Console.WriteLine(a);
                            Console.WriteLine("want to continue or return to main menu(c/m)");
                            string answer = Console.ReadLine();
                            if (answer == "c")
                            {
                                v++;
                                Console.WriteLine(a);
                            }
                            else
                            {
                                goto repeat;
                            }
                        }
                        break;
                    case "3": break;

                    default: goto repeat;
                }
            }
            catch (Exception p)
            {
                Console.WriteLine("invalid key entred");
            }
            finally
            {

            }

        }
    }
}
