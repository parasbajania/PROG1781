﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A3ParasBajaniaP2
{
    class Program
    {
        static void Main(string[] args)
        {
            int operate = 0;
            double res = 0;

            {
                Console.WriteLine("Enter the first number :");
                string FirstNumber = Console.ReadLine();
                double firstNumber = Convert.ToDouble(FirstNumber);

                Console.WriteLine("Enter the second number :");
                string SecondNo = Console.ReadLine();
                double secondNumber = Convert.ToDouble(SecondNo);

                Console.WriteLine("Enter the operation + (addition), - (substraction), * (multiplication), / (division), ^ (exposant) or % (reste) :");
                string rin = Console.ReadLine();

                if (rin == "+" || rin == "addition")
                {
                    operate = 1;
                }
                else if (rin == "-" || rin == "sudstraction")
                {
                    operate = 2;
                }
                else if (rin == "*" || rin == "multiplication")
                {
                    operate = 3;
                }
                else if (rin == "/" || rin == "division")
                {
                    operate = 4;
                }
                else if (rin == "^" || rin == "exposant")
                {
                    operate = 5;
                }
                else if (rin == "%" || rin == "reste")
                {
                    operate = 6;
                }

                switch (operate)
                {
                    case 1:
                        res = firstNumber + secondNumber;
                        break;

                    case 2:
                        res = firstNumber - secondNumber;
                        break;

                    case 3:
                        res = firstNumber * secondNumber;
                        break;

                    case 4:
                        res = firstNumber / secondNumber;
                        break;

                    case 5:
                        res = Math.Pow(firstNumber, secondNumber);
                        break;

                    case 6:
                        res = firstNumber % secondNumber;
                        break;
                }
                Console.WriteLine(" Result of " + firstNumber + " " + rin + " " + secondNumber + " = " + res + ".");
                Console.ReadKey();
            }

        }
    }
}
